---
title: Mybatis环境搭建
tags: 
- Mybatis环境搭建
categories: 
- Mybaits
---

# 下载MyBatis

方式一：通过maven下载

方式二：手动下载

[Mybatis](https://github.com/mybatis/mybatis-3/releases)

解压后可得lib包或者jar包，我们选择jar包导入


